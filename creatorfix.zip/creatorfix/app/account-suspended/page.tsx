export default function AccountSuspendedPage() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-ink-950 px-4 text-center text-white">
      <div>
        <h1 className="font-display text-2xl font-semibold">
          Account not active
        </h1>
        <p className="mt-2 text-white/60">
          Your account is currently suspended, banned, or pending review.
          Contact support if you believe this is a mistake.
        </p>
      </div>
    </main>
  );
}
