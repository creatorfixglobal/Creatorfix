import { requireRole } from "@/lib/auth/require-role";

export default async function AdminDashboardPage() {
  const profile = await requireRole(["admin"]);

  return (
    <main className="mx-auto max-w-4xl px-6 py-12">
      <h1 className="font-display text-2xl font-semibold text-ink-950">
        Admin — {profile.displayName}
      </h1>
      <p className="mt-2 text-sm text-ink-700">
        Platform, problem, fee, provider, deposit, withdrawal, and dispute
        management land here in Phase 2 onward.
      </p>
    </main>
  );
}
