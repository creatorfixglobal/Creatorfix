import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-ink-950 text-white">
      <section className="mx-auto max-w-3xl px-6 py-24 text-center">
        <h1 className="font-display text-4xl font-semibold sm:text-5xl">
          Creator<span className="text-signal-400">Fix</span>
        </h1>
        <p className="mt-4 text-lg text-white/70">
          Your Creator Problems. Our Solutions.
        </p>
        <p className="mx-auto mt-6 max-w-xl text-white/60">
          Find verified help for Facebook, YouTube, TikTok, Instagram, X, and
          LinkedIn account issues — or offer your expertise as a provider.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <Link href="/register" className="cf-button-primary">
            Get started
          </Link>
          <Link
            href="/login"
            className="inline-flex items-center justify-center rounded-lg border border-white/20 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/10"
          >
            Log in
          </Link>
        </div>
      </section>
    </main>
  );
}
