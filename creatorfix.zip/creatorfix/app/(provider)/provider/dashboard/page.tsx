import { requireRole } from "@/lib/auth/require-role";
import { requireVerifiedPage } from "@/lib/auth/require-verified";
import { createServerSupabaseClient } from "@/lib/supabase/server";

export default async function ProviderDashboardPage() {
  const profile = await requireRole(["provider"]);
  await requireVerifiedPage(profile); // identity verification, separate from provider_profiles.verification_status
  const supabase = createServerSupabaseClient();

  const { data: providerProfile } = await supabase
    .from("provider_profiles")
    .select("verification_status, status, rating_average, completed_orders")
    .eq("user_id", profile.id)
    .single();

  return (
    <main className="mx-auto max-w-4xl px-6 py-12">
      <h1 className="font-display text-2xl font-semibold text-ink-950">
        Welcome, {profile.displayName}
      </h1>

      <div className="mt-6 cf-card p-6">
        <p className="text-sm text-ink-700">Verification status</p>
        <p className="mt-1 text-lg font-medium capitalize text-ink-950">
          {providerProfile?.verification_status ?? "unverified"}
        </p>
        {providerProfile?.verification_status !== "verified" && (
          <p className="mt-2 text-xs text-ink-700/60">
            Complete verification to start publishing services.
          </p>
        )}
      </div>
    </main>
  );
}
