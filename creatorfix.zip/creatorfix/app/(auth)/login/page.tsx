"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { loginAction } from "@/actions/auth.actions";
import { AuthShell, Field } from "@/components/auth-shell";

export default function LoginPage() {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [formError, setFormError] = useState<string | null>(null);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setFormError(null);

    const formData = new FormData(e.currentTarget);
    const raw = {
      email: formData.get("email"),
      password: formData.get("password"),
    };

    startTransition(async () => {
      const result = await loginAction(raw);
      if (!result.ok) {
        setFormError(result.error);
        return;
      }
      // Server re-derives role from the profiles row on the next
      // protected page load — the client never decides where "admin"
      // or "provider" goes, so there's no redirect target to spoof here.
      router.push("/redirecting");
      router.refresh();
    });
  }

  return (
    <AuthShell title="Log in to CreatorFix">
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <Field label="Email" name="email" type="email" />
        <Field label="Password" name="password" type="password" />

        {formError && <p className="cf-error">{formError}</p>}

        <button type="submit" disabled={isPending} className="cf-button-primary w-full">
          {isPending ? "Logging in..." : "Log in"}
        </button>
      </form>

      <div className="mt-4 flex items-center justify-between text-sm">
        <Link href="/reset-password" className="text-signal-600 underline">
          Forgot password?
        </Link>
        <Link href="/register" className="text-signal-600 underline">
          Create account
        </Link>
      </div>
    </AuthShell>
  );
}
