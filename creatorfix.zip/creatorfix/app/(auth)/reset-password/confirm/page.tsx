"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { confirmPasswordResetAction } from "@/actions/auth.actions";
import { resetPasswordConfirmSchema } from "@/lib/validation/auth.schema";
import { AuthShell, Field } from "@/components/auth-shell";

export default function ResetPasswordConfirmPage() {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [formError, setFormError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]>>({});

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setFormError(null);
    setFieldErrors({});

    const formData = new FormData(e.currentTarget);
    const raw = {
      password: formData.get("password"),
      confirmPassword: formData.get("confirmPassword"),
    };

    const clientCheck = resetPasswordConfirmSchema.safeParse(raw);
    if (!clientCheck.success) {
      setFieldErrors(clientCheck.error.flatten().fieldErrors);
      return;
    }

    startTransition(async () => {
      const result = await confirmPasswordResetAction(raw);
      if (!result.ok) {
        setFormError(result.error);
        return;
      }
      router.push("/login");
    });
  }

  return (
    <AuthShell title="Set a new password">
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <Field
          label="New password"
          name="password"
          type="password"
          errors={fieldErrors.password}
        />
        <Field
          label="Confirm new password"
          name="confirmPassword"
          type="password"
          errors={fieldErrors.confirmPassword}
        />

        {formError && <p className="cf-error">{formError}</p>}

        <button type="submit" disabled={isPending} className="cf-button-primary w-full">
          {isPending ? "Saving..." : "Save new password"}
        </button>
      </form>
    </AuthShell>
  );
}
