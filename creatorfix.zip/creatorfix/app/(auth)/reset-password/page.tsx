"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { requestPasswordResetAction } from "@/actions/auth.actions";
import { AuthShell, Field } from "@/components/auth-shell";

export default function ResetPasswordRequestPage() {
  const [isPending, startTransition] = useTransition();
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const raw = { email: formData.get("email") };

    startTransition(async () => {
      await requestPasswordResetAction(raw);
      // Always show the same success state, regardless of whether the
      // email exists — requestPasswordResetAction never reveals that.
      setSubmitted(true);
    });
  }

  if (submitted) {
    return (
      <AuthShell title="Check your email">
        <p className="text-sm text-ink-700">
          If an account exists for that email, we&apos;ve sent a password
          reset link.
        </p>
        <Link href="/login" className="mt-4 inline-block text-sm text-signal-600 underline">
          Back to login
        </Link>
      </AuthShell>
    );
  }

  return (
    <AuthShell title="Reset your password">
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <Field label="Email" name="email" type="email" />
        <button type="submit" disabled={isPending} className="cf-button-primary w-full">
          {isPending ? "Sending..." : "Send reset link"}
        </button>
      </form>
    </AuthShell>
  );
}
