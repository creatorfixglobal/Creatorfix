import { redirect } from "next/navigation";
import { getOptionalProfile } from "@/lib/auth/require-role";
import { getVerificationStatus } from "@/lib/auth/require-verified";

/**
 * Landing spot right after login. The destination is decided entirely
 * by server-side lookups — the login form never passes a role or a
 * redirect target, so there is nothing here for a client to spoof.
 *
 * Identity verification is checked BEFORE role-based routing: an
 * unverified admin account would be unusual, but customers and
 * providers both hit /verify first regardless of role, since neither
 * role's dashboard is usable pre-verification anyway.
 */
export default async function RedirectingPage() {
  const profile = await getOptionalProfile();

  if (!profile) {
    redirect("/login");
  }

  if (profile!.role === "admin") redirect("/admin");

  const status = await getVerificationStatus(profile!.id);
  if (status !== "verified") {
    redirect("/verify");
  }

  if (profile!.role === "provider") redirect("/provider/dashboard");
  redirect("/dashboard");
}
