"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { registerAction } from "@/actions/auth.actions";
import { registerSchema } from "@/lib/validation/auth.schema";
import { AuthShell, Field } from "@/components/auth-shell";

export default function RegisterPage() {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [formError, setFormError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]>>({});
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setFormError(null);
    setFieldErrors({});

    const formData = new FormData(e.currentTarget);
    const raw = {
      email: formData.get("email"),
      password: formData.get("password"),
      username: formData.get("username"),
      displayName: formData.get("displayName"),
      // No role field — every account registers as 'customer'. Providers
      // apply separately after identity verification (see /apply-provider).
    };

    const clientCheck = registerSchema.safeParse(raw);
    if (!clientCheck.success) {
      setFieldErrors(clientCheck.error.flatten().fieldErrors);
      return;
    }

    startTransition(async () => {
      const result = await registerAction(raw);
      if (!result.ok) {
        setFormError(result.error);
        if (result.fieldErrors) setFieldErrors(result.fieldErrors);
        return;
      }
      setSubmitted(true);
    });
  }

  if (submitted) {
    return (
      <AuthShell title="Check your email">
        <p className="text-sm text-ink-700">
          We sent a verification link to your email address. Verify your
          account, then{" "}
          <Link href="/login" className="text-signal-600 underline">
            log in
          </Link>
          .
        </p>
      </AuthShell>
    );
  }

  return (
    <AuthShell title="Create your CreatorFix account">
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <p className="text-sm text-ink-700/70">
          Every account starts as a customer. You&apos;ll verify your identity
          next — you can apply to become a provider afterward.
        </p>

        <Field
          label="Display name"
          name="displayName"
          errors={fieldErrors.displayName}
        />
        <Field
          label="Username"
          name="username"
          errors={fieldErrors.username}
          hint="Lowercase letters, numbers, underscores only"
        />
        <Field
          label="Email"
          name="email"
          type="email"
          errors={fieldErrors.email}
        />
        <Field
          label="Password"
          name="password"
          type="password"
          errors={fieldErrors.password}
          hint="At least 8 characters, one uppercase letter, one number"
        />

        {formError && <p className="cf-error">{formError}</p>}

        <button type="submit" disabled={isPending} className="cf-button-primary w-full">
          {isPending ? "Creating account..." : "Create account"}
        </button>
      </form>

      <p className="mt-4 text-center text-sm text-ink-700">
        Already have an account?{" "}
        <Link href="/login" className="text-signal-600 underline">
          Log in
        </Link>
      </p>
    </AuthShell>
  );
}


