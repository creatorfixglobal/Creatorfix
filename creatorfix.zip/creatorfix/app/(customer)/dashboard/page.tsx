import { requireRole } from "@/lib/auth/require-role";
import { requireVerifiedPage } from "@/lib/auth/require-verified";
import { createServerSupabaseClient } from "@/lib/supabase/server";

export default async function CustomerDashboardPage() {
  const profile = await requireRole(["customer"]);
  await requireVerifiedPage(profile); // redirects to /verify if not verified
  const supabase = createServerSupabaseClient();

  const { data: wallet } = await supabase
    .from("wallets")
    .select("balance, reserved_balance")
    .eq("user_id", profile.id)
    .single();

  return (
    <main className="mx-auto max-w-4xl px-6 py-12">
      <h1 className="font-display text-2xl font-semibold text-ink-950">
        Welcome back, {profile.displayName}
      </h1>
      <div className="mt-6 cf-card p-6">
        <p className="text-sm text-ink-700">Wallet balance</p>
        <p className="mt-1 text-3xl font-semibold text-ink-950">
          ৳{((wallet?.balance ?? 0) / 100).toFixed(2)}
        </p>
        {(wallet?.reserved_balance ?? 0) > 0 && (
          <p className="mt-1 text-xs text-ink-700/60">
            ৳{((wallet?.reserved_balance ?? 0) / 100).toFixed(2)} reserved in
            active orders
          </p>
        )}
      </div>
    </main>
  );
}
