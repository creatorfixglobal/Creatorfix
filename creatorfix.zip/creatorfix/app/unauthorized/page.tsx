export default function UnauthorizedPage() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-ink-950 px-4 text-center text-white">
      <div>
        <h1 className="font-display text-2xl font-semibold">Not authorized</h1>
        <p className="mt-2 text-white/60">
          You don&apos;t have access to this page with your current account.
        </p>
      </div>
    </main>
  );
}
